using System;
using System.IO;
using CelestialLibrary;
using NUnit.Framework;

namespace CelestialLibrary.Tests
{
    [TestFixture]
    public class CelestialBodyTests
    {
        [Test]
        public void Constructor_ValidParameters_InitializesProperties()
        {
            var body = new CelestialBody("Earth", 5.97, 6371);

            Assert.AreEqual("Earth", body.Name);
            Assert.AreEqual(5.97, body.Mass);
            Assert.AreEqual(6371, body.Radius);
            Assert.IsNotNull(body.Id);
        }

        [Test]
        public void Name_SetNull_DefaultsToUnknown()
        {
            var body = new CelestialBody();
            body.Name = null;

            Assert.AreEqual("Unknown", body.Name);
        }

        [Test]
        public void Mass_NegativeValue_ThrowsArgumentException()
        {
            var body = new CelestialBody();
            Assert.Throws<ArgumentException>(() => body.Mass = -1);
        }

        [Test]
        public void Radius_ZeroValue_ThrowsArgumentException()
        {
            var body = new CelestialBody();
            Assert.Throws<ArgumentException>(() => body.Radius = 0);
        }

        [Test]
        public void Show_DisplaysCorrectInformation()
        {
            var body = new CelestialBody("Mars", 0.642, 3390);
            using (var sw = new StringWriter())
            {
                Console.SetOut(sw);
                body.Show();
                var output = sw.ToString();

                StringAssert.Contains("Name: Mars", output);
                StringAssert.Contains("Mass: 0.642", output);
                StringAssert.Contains("Radius: 3390", output);
            }
        }

        [Test]
        public void Equals_SameName_ReturnsTrue()
        {
            var body1 = new CelestialBody("Earth", 5.97, 6371);
            var body2 = new CelestialBody("Earth", 4.87, 6052);

            Assert.IsTrue(body1.Equals(body2));
        }

        [Test]
        public void Clone_CreatesDeepCopy()
        {
            var original = new CelestialBody("Earth", 5.97, 6371);
            original.Id.Number = 42;
            var clone = (CelestialBody)original.Clone();

            Assert.AreEqual(original.Name, clone.Name);
            Assert.AreEqual(original.Id.Number, clone.Id.Number);
            Assert.AreNotSame(original.Id, clone.Id);
        }

        [Test]
        public void CompareTo_BasedOnMass_CorrectOrdering()
        {
            var body1 = new CelestialBody("Earth", 5.97, 6371);
            var body2 = new CelestialBody("Mars", 0.642, 3390);

            Assert.Greater(body1.CompareTo(body2), 0);
            Assert.Less(body2.CompareTo(body1), 0);
        }
    }

    [TestFixture]
    public class PlanetTests
    {
        [Test]
        public void Constructor_ValidParameters_InitializesSatellites()
        {
            var planet = new Planet("Earth", 5.97, 6371, 1);

            Assert.AreEqual(1, planet.NumSatellites);
        }

        [Test]
        public void NumSatellites_NegativeValue_ThrowsArgumentException()
        {
            var planet = new Planet();
            Assert.Throws<ArgumentException>(() => planet.NumSatellites = -1);
        }

        [Test]
        public void Show_DisplaysSatelliteCount()
        {
            var planet = new Planet("Earth", 5.97, 6371, 1);
            using (var sw = new StringWriter())
            {
                Console.SetOut(sw);
                planet.Show();
                var output = sw.ToString();

                StringAssert.Contains("Number of satellites: 1", output);
            }
        }

        [Test]
        public void RandomInit_SetsValidRandomValues()
        {
            var planet = new Planet();
            planet.RandomInit();

            Assert.IsNotNull(planet.Name);
            Assert.Greater(planet.Mass, 0);
            Assert.Greater(planet.Radius, 0);
            Assert.GreaterOrEqual(planet.NumSatellites, 0);
        }

        [Test]
        public void BaseObject_ReturnsCorrectCelestialBody()
        {
            var planet = new Planet("Earth", 5.97, 6371, 1);
            planet.Id.Number = 42;
            var baseObj = planet.BaseObject;

            Assert.AreEqual("Earth", baseObj.Name);
            Assert.AreEqual(42, baseObj.Id.Number);
        }
    }

    [TestFixture]
    public class StarTests
    {
        [Test]
        public void Constructor_ValidParameters_InitializesTemperature()
        {
            var star = new Star("Sun", 1.989, 696340, 5778);

            Assert.AreEqual(5778, star.Temperature);
        }

        [Test]
        public void Show_DisplaysTemperature()
        {
            var star = new Star("Sun", 1.989, 696340, 5778);
            using (var sw = new StringWriter())
            {
                Console.SetOut(sw);
                star.Show();
                var output = sw.ToString();

                StringAssert.Contains("Temperature: 5778", output);
            }
        }

        [Test]
        public void RandomInit_SetsValidTemperature()
        {
            var star = new Star();
            star.RandomInit();

            Assert.GreaterOrEqual(star.Temperature, 2000);
            Assert.LessOrEqual(star.Temperature, 10000);
        }

        [Test]
        public void Equals_DifferentTemperature_ReturnsFalse()
        {
            var star1 = new Star("Sun", 1.989, 696340, 5778);
            var star2 = new Star("Sun", 1.989, 696340, 6000);

            Assert.IsFalse(star1.Equals(star2));
        }
    }

    [TestFixture]
    public class GasGiantTests
    {
        [Test]
        public void Constructor_ValidParameters_InitializesRings()
        {
            var gasGiant = new GasGiant("Jupiter", 1.898, 69911, 79, true);

            Assert.IsTrue(gasGiant.HasRings);
        }

        [Test]
        public void Show_DisplaysRingsInformation()
        {
            var gasGiant = new GasGiant("Jupiter", 1.898, 69911, 79, true);
            using (var sw = new StringWriter())
            {
                Console.SetOut(sw);
                gasGiant.Show();
                var output = sw.ToString();

                StringAssert.Contains("Has rings: Yes", output);
            }
        }

        [Test]
        public void RandomInit_SetsValidRingsValue()
        {
            var gasGiant = new GasGiant();
            gasGiant.RandomInit();

            Assert.IsTrue(gasGiant.HasRings || !gasGiant.HasRings);
        }

        [Test]
        public void Equals_DifferentRings_ReturnsFalse()
        {
            var gasGiant1 = new GasGiant("Jupiter", 1.898, 69911, 79, true);
            var gasGiant2 = new GasGiant("Jupiter", 1.898, 69911, 79, false);

            Assert.IsFalse(gasGiant1.Equals(gasGiant2));
        }
    }

    [TestFixture]
    public class HashTableTests
    {
        private HashTable<CelestialBody> _table;

        [SetUp]
        public void Setup()
        {
            _table = new HashTable<CelestialBody>(5);
        }

        [Test]
        public void Constructor_ValidSize_CreatesTable()
        {
            Assert.AreEqual(5, _table.Size);
            Assert.AreEqual(0, _table.Count);
        }

        [Test]
        public void Add_NewItem_IncreasesCount()
        {
            var planet = new Planet("Earth", 5.97, 6371, 1);
            var result = _table.Add(planet);

            Assert.IsTrue(result);
            Assert.AreEqual(1, _table.Count);
        }

        [Test]
        public void Add_DuplicateItem_ReturnsFalse()
        {
            var planet = new Planet("Earth", 5.97, 6371, 1);
            _table.Add(planet);
            var result = _table.Add(planet);

            Assert.IsFalse(result);
            Assert.AreEqual(1, _table.Count);
        }

        [Test]
        public void FindByName_ExistingItem_ReturnsItem()
        {
            var planet = new Planet("Earth", 5.97, 6371, 1);
            _table.Add(planet);

            var found = _table.FindByName("Earth");

            Assert.IsNotNull(found);
            Assert.AreEqual("Earth", found.Name);
        }

        [Test]
        public void FindByName_NonExistingItem_ReturnsNull()
        {
            var found = _table.FindByName("Mars");
            Assert.IsNull(found);
        }

        [Test]
        public void Remove_ExistingItem_DecreasesCount()
        {
            var planet = new Planet("Earth", 5.97, 6371, 1);
            _table.Add(planet);

            var result = _table.Remove(planet);

            Assert.IsTrue(result);
            Assert.AreEqual(0, _table.Count);
        }

        [Test]
        public void Print_EmptyTable_OutputsCorrectStructure()
        {
            using (var sw = new StringWriter())
            {
                Console.SetOut(sw);
                _table.Print();
                var output = sw.ToString();

                for (int i = 0; i < _table.Size; i++)
                {
                    StringAssert.Contains($"{i}: null", output);
                }
            }
        }

        [Test]
        public void GetEnumerator_ReturnsAllItems()
        {
            var planet1 = new Planet("Earth", 5.97, 6371, 1);
            var planet2 = new Planet("Mars", 0.642, 3390, 2);
            _table.Add(planet1);
            _table.Add(planet2);

            int count = 0;
            foreach (var item in _table)
            {
                count++;
            }

            Assert.AreEqual(2, count);
        }

        [Test]
        public void Contains_ExistingItem_ReturnsTrue()
        {
            var planet = new Planet("Earth", 5.97, 6371, 1);
            _table.Add(planet);

            Assert.IsTrue(_table.Contains(planet));
        }

        [Test]
        public void ContainsName_NonExistingName_ReturnsFalse()
        {
            Assert.IsFalse(_table.ContainsName("Mars"));
        }
    }
}